const AWS = require("aws-sdk");
AWS.config.update({ region: "us-east-2" });


const { JSDOM } = require("jsdom");
const https = require("https");

//const urlhostregex = new RegExp('^(?:https://)|(?:http://).*(?=/)');

/* Expected Input Payload
 * {
 *      #The app ids to fetch web page info for
 *      app_ids = [] 
 * }
*/

//This function handles scraping the Steam Store pages for missing info, and then passes it back to the main function to be added to DynamoDB
exports.handler = async function (event, context) {
    let requestURL = process.env.searchURL;
    const app_ids = event.app_ids;
    return await fetchStoreInfo(requestURL, app_ids);
};

async function fetchStoreInfo(requestURL, app_ids) {
    console.log("[fetchStoreInfo] Lambda call received");

    let response = {}

    let htmlParserInput = {
        "store_pages": []
    }
    const generateStorePageEntry = (app_id, html) => { return { "app_id": app_id, "html": html } };


    //Cycle through each app_id and retrieve its store page HTML. Add that HTML to htmlParserInput to be passed onto parseHTMLForGameFeatures
    for (const id of app_ids) {
        //Add ID for this request
        requestURL += id;

        const MAX_REDIRECTS = 5;
        let numRedirects = 0;
        let storePageResponse;

        //Loop for potential redirects
        do {
            console.log(`Starting Loop to handle redirects. Attempt ${numRedirects + 1}`);

            storePageResponse = await getStorePage(requestURL);

            console.log(`Response Received:\n${JSON.stringify(storePageResponse)}`);

            if (storePageResponse.statusCode >= 300 && storePageResponse.statusCode < 400) {
                console.log(`3XX status code received (${storePageResponse.statusCode})`)
                try {
                    let redirectURL = new URL(storePageResponse.headers.location);
                    getStorePage(storePageResponse.headers.location);
                }
                catch (e) {
                    //console.log(JSON.stringify(e));
                }
            }
            else if (storePageResponse.statusCode > 400) {
                //console.log("Bad responnse received, status code 400");
            }
            //HTML response received, add it to htmlParserInput
            else {
                console.log(JSON.stringify(storePageResponse));
                htmlParserInput.store_pages.push(generateStorePageEntry(id, storePageResponse.body))
                break;
            }

            numRedirects++;
        } while (numRedirects < MAX_REDIRECTS)


        //Trim ID for next iteration
        requestURL = requestURL.slice(0, requestURL.lastIndexOf("/") + 1);
    }

    //HTML has been retrieved, now get final features
    response = parseHTMLForGameFeatures(htmlParserInput);
    return response;

}

///Expected input: URL to be requested (string)
async function getStorePage(newURL) {
    const URLObj = new URL(newURL);
    const requestOptions = {
        host: URLObj.host,
        path: URLObj.pathname,
        method: "GET"
    }

    console.log(`host: ${requestOptions.host}\npath: ${requestOptions.path}`);

    return await new Promise((resolve, reject) => {
        let req = https.request(requestOptions, function (incomingMessage) {

            let response = {
                statusCode: incomingMessage.statusCode,
                headers: incomingMessage.headers,
                body: []
            };

            incomingMessage.on('data', function (chunk) {
                console.log("Adding Data");
                response.body.push(chunk);
            });

            incomingMessage.on('end', function () {
                console.log("End Response Triggered");
                response.body = response.body.join();

                resolve(response);
            });

            incomingMessage.on('error', function (err) {
                console.log("Error response trigger");
                reject(`error: ${JSON.stringify(err)}`);
            });
        }).end();
    }).then(val => {
        console.log(`HTTP Response: ${JSON.stringify(val)}`);
        return val;
    });
}

/* Expected Input:
    {
        store_pages: [
            {
                app_id: <id (string)>
                html: <html (string)>
            }
        ]
            
    }
    
    Expected Output:
    {
        app_id_features: [
            {
                app_id: <id (string)>
                features: {
                    <feature1>: <boolean>,
                    <feature2>: <boolean>,
                    <featureN>: <boolean>,
                }
            }
        ]
    }
*/
function parseHTMLForGameFeatures(input) {
    //Determine Game Features to Search For (probably parse some file or smthn)
    const SEARCH_STRINGS = process.env.searchStrings.split(',').map(rawString => rawString.toLowerCase());

    let response = {
        "app_id_features": []
    }
    const generateAppIdFeatureObject = (app_id, features) => { return { "app_id": app_id, "features": features }; }

    //Loop and look for game features
    for (const storePage of input.store_pages) {
        const pageHtml = new JSDOM(storePage.html).window.document;
        let foundFeatures = {};

        //Find matches
        for (const node of pageHtml.getElementsByClassName("label")/*pageHtml.querySelectorAll("div.game_area_features_list_ctn div.label")*/) {
            let nodeTextContentLower = node.textContent.toLowerCase();
            console.log(nodeTextContentLower);
            if (SEARCH_STRINGS.includes(nodeTextContentLower)) {
                console.log("Feature Found");
                foundFeatures[`${nodeTextContentLower}`] = true;
            }
        }


        //Set all search strings that weren't found to false in response
        SEARCH_STRINGS.filter(searchString => !(searchString in foundFeatures))
            .forEach(missingString => foundFeatures[`${missingString}`] = false);

        response.app_id_features.push(generateAppIdFeatureObject(input.app_id, foundFeatures));
    }

    console.log(`Done looking for matches, here's the final object: ${response}`);

    return response;


}